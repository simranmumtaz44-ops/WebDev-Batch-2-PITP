// ACCORDION FUNCTIONALITY
const accordions = document.querySelectorAll(".accordion");

accordions.forEach(acc => {
  acc.addEventListener("click", () => {
    // Toggle panel
    const panel = acc.nextElementSibling;
    panel.style.maxHeight = panel.style.maxHeight ? null : panel.scrollHeight + "px";

    // Toggle active class for styling if needed
    acc.classList.toggle("active");
  });
});

// BOOKING MODAL
const modal = document.getElementById("bookingModal");
const closeModal = document.getElementById("closeBooking");
const bookButtons = document.querySelectorAll(".bookBtn");

// Open modal on any "Book Now" click
bookButtons.forEach(btn => {
  btn.addEventListener("click", () => {
    modal.style.display = "flex";
  });
});

// Close modal when clicking the X
closeModal.addEventListener("click", () => {
  modal.style.display = "none";
});

// Close modal if clicking outside modal content
window.addEventListener("click", (e) => {
  if(e.target === modal){
    modal.style.display = "none";
  }
});

// FORM SUBMISSION (for demo)
const bookingForm = document.getElementById("bookingForm");
bookingForm.addEventListener("submit", (e) => {
  e.preventDefault();
  alert("Thank you! Your booking request has been received.");
  modal.style.display = "none";
  bookingForm.reset();
});

